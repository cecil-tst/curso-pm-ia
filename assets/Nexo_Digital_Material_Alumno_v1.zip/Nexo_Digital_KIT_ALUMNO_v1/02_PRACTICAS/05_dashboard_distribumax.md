# Práctica 05 · Dashboard comercial y decisión ejecutiva
**Área:** Transformación empresarial + Product/Data | **Duración:** 75–100 min | **M04 · L3 y M05 · L1**

## Caso realista
DistribuMax quiere un panel de ventas y pipeline. Dirección trae un resumen con cifras dudosas. Marina debe construir un sistema mínimo de reporting cuyas métricas puedan auditarse.

## Archivos
- `01_DATOS/DISTRIBUMAX/diccionario_kpi.md`
- `01_DATOS/DISTRIBUMAX/ventas_octubre_2026.csv`
- `01_DATOS/DISTRIBUMAX/oportunidades_crm.csv`
- `01_DATOS/DISTRIBUMAX/probabilidades_etapas.csv`
- `01_DATOS/DISTRIBUMAX/resumen_comercial_borrador.md`

## Entregables
- `dashboard_distribumax.xlsx` **o** `dashboard_distribumax.html` (archivo local sin conexiones externas): KPI, gráficos/tablas y fuente.
- `control_datos.md`: duplicados, exclusiones, regla aplicada, incidencia y reconciliación.
- `nota_direccion.md`: máximo 350 palabras; tres insights verificables, decisiones propuestas y límites del dato.

## Pasos
1. Lee el diccionario. Enumera los KPI con sus fórmulas antes de calcular.
2. Audita el CSV de ventas: unicidad por ID, signos de abonos, estados y facturas anuladas.
3. Construye el cálculo desde **fuentes deduplicadas**. No uses el resumen comercial como verdad.
4. Separa facturación, cobro y pipeline abierto (realidades distintas). Aplica las probabilidades por etapa y excluye oportunidades cerradas.
5. Crea dashboard con: facturación neta, objetivo, desviación, cobrado, pendiente, pipeline abierto, ponderado, facturación por región y pipeline por etapa. Añade periodos y unidades.
6. Comprueba manualmente dos KPIs a partir de filas de origen. Documenta anomalías.
7. Redacta la nota ejecutiva con recomendación específica: qué investigar y qué decisión evitar hasta tener mejor evidencia.

## Prompt inicial
> Trabaja como analista de negocio que apoya a una responsable de transformación. Usa solo el diccionario KPI y las tablas recibidas. Primero inspecciona IDs duplicados, abonos y estados; presenta un registro de limpieza auditable. Calcula después los KPI con fórmulas explícitas, mostrando inclusiones/exclusiones y valores sin IVA. Diseña un dashboard local usable por dirección, sin inventar datos ni fechas. Contrasta las afirmaciones del borrador comercial. Si detectas ambigüedad, márcala y pide confirmación antes de presentarla como certeza.

## Aceptación
- El registro identifica documentos duplicados, excluye anulados y aplica abonos.
- Las tarjetas usan periodos, definición y fuente; los importes son reconciliables.
- Pipeline ponderado usa el mapeo de probabilidades, sin sumar estados cerrados.
- El informe distingue ingresos facturados de cobros y de oportunidades futuras.
- No afirma conversiones, proyecciones garantizadas ni ROI que estos archivos no permiten calcular.

## Reflexión
¿Qué controles de datos y gobierno exigirías antes de conectar en vivo un ERP y un CRM de un cliente real?

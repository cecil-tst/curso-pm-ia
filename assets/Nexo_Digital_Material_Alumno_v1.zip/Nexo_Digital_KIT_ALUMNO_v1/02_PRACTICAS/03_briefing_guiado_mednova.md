# Práctica 03 · Discovery guiado de CRM e intranet comercial
**Área:** Product + Project | **Duración:** 60–80 min | **M02 · L2**

## Caso realista
MedNova solicita un CRM y una intranet. El briefing inicial mezcla objetivos de negocio, deseos de producto y fechas vagas. Sara, Product Manager de Nexo, debe aclararlo antes de emitir propuesta.

## Archivos
- Inicialmente aporta **solo** `01_DATOS/MEDNOVA/brief_inicial.md`.
- Mantén `01_DATOS/MEDNOVA/ficha_respuestas_autorizadas.md` **cerrado** hasta que la IA pregunte. Úsalo para responder **una pregunta a la vez**.
- Consulta al final `01_DATOS/MEDNOVA/notas_de_stakeholders.md` para contrastar y enriquecer, dejando pendientes.

## Entregables
- `entrevista_log.md`: preguntas sucesivas de la IA, respuesta realmente autorizada y hallazgos.
- `brief_producto_mednova.md`: problema, usuarios, oportunidades, alcance piloto vs fases posteriores, restricciones, KPI, fuentes y dudas.
- `backlog_inicial.csv`: ID, historia, problema, evidencia, prioridad **propuesta**, dependencias y condición de aceptación.
- `lista_validaciones_cliente.md`: máximo cinco preguntas nuevas para siguiente reunión, ordenadas por impacto.

## Pasos
1. Abre un chat nuevo. Comparte únicamente el brief inicial y ejecuta el prompt.
2. Responde las preguntas de la IA **de una en una** usando literalmente los contenidos de la ficha autorizada; si no hay respuesta, di `NO CONFIRMADO`. No anticipes la siguiente respuesta.
3. Tras un máximo de cinco preguntas, pide un brief con tres etiquetas por afirmación: **CONFIRMADO / HIPÓTESIS / POR VALIDAR**.
4. Contrasta con las notas de stakeholders. Comprueba que el acceso regional y la duplicidad de oportunidades se han considerado.
5. Solicita backlog de MVP ordenado por valor y dependencia, no un proyecto gigantesco con alcance ficticio.
6. Valida que el presupuesto, las integraciones y la fecha de producción **no se afirman como cerrados**.

## Prompt listo para copiar
> Actúa como Product Manager de una agencia digital. Antes de redactar un brief o proponer funcionalidades, entrevístame para descubrir requisitos y riesgos del CRM e intranet de MedNova. Haz un máximo de cinco preguntas, **una por turno**, con opciones cuando resulten útiles y opción de respuesta libre. No presupongas el CRM, presupuesto, usuarios o fecha de producción. Al terminar, construye un brief estructurado y separa hechos, hipótesis y decisiones pendientes. No inventes datos.

## Aceptación
- Máximo cinco preguntas, secuenciales, pertinentes y no redundantes.
- El brief responde claramente **quién usa qué, para qué, con qué restricciones y cómo medirlo**.
- Se separa CRM de oportunidades de la intranet documental; se declara su posible dependencia.
- El acceso por roles está contemplado; no se manejan datos de pacientes.
- El presupuesto, integración ERP y go-live real no se presentan como aprobados.

## Reflexión
¿Qué requisitos debería confirmar PM antes de estimar tiempo/coste, y cuáles son decisiones de Product que requieren discovery?

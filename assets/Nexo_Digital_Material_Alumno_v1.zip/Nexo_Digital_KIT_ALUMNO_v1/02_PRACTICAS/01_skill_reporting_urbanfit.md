# Práctica 01 · Crear y validar una skill de reporting semanal
**Área:** PM + operaciones de marketing + transformación | **Duración:** 75–100 min | **M04 · L4**

## Caso realista
Laura, account manager de UrbanFit, dedica tiempo todos los lunes a consolidar plataformas publicitarias, horas del equipo y compromisos pendientes. Quiere un procedimiento reutilizable **sin inventar datos, ni confundir gasto de medios con honorarios de agencia**.

## Archivos de entrada
1. `00_AGENCIA/reglas_de_trabajo.md`
2. `01_DATOS/URBANFIT/brief_servicio.md`
3. `01_DATOS/URBANFIT/rendimiento_ads.csv`
4. `01_DATOS/URBANFIT/horas_equipo.csv`
5. `01_DATOS/URBANFIT/pendientes_creativos.md`

## Misión y resultado que se pide
Crear `skill_status_urbanfit.md` con **descripción de activación/no activación, reglas y formato**; generar `status_W45.md` y `status_W46.md`; entregar `pruebas_skill.csv` (caso, activación esperada, activación observada, veredicto, fallo, cambio).

## Instrucciones paso a paso
1. Lee el acuerdo UrbanFit, identifica KPI, presupuesto, responsables, datos de entrada y límites.
2. Redacta una skill: solo se activa cuando se solicite explícitamente **un informe semanal de campaña o reporte de cuenta**. No se activa para pedir ideas creativas, copies, transcripciones sueltas o una explicación general de métricas.
3. Incluye como salida **KPI / avance / incidencias / riesgos / decisiones / próximas acciones**, con las fuentes y el corte temporal. El cálculo debe usar los archivos, no suposiciones.
4. Prueba la skill con W45 y W46, por separado. Para W46 solicita una explicación de los cambios respecto a W45. No conviertas los MQL ausentes en cero.
5. Haz **tres ejecuciones con la misma entrada W46**. Contrasta invariantes numéricos, no la redacción exacta.
6. Ejecuta dos pruebas negativas (ideas de banner y resumen de un correo hipotético). La skill de status **no debe activarse**.
7. Si encuentras un fallo repetible, cambia el documento de la skill, explica por qué y repite todas las pruebas. Conserva versión anterior para poder revertir.
8. Propón el paso del informe que necesita aprobación humana antes del envío. No envíes correos reales.

## Prompt inicial para la IA
> Actúa como responsable de operaciones de una agencia. Diseña un procedimiento reutilizable de informe semanal a partir de los archivos aportados. Primero define cuándo DEBE activarse y cuándo NO. Después redacta su flujo de extracción, cálculos, validaciones, tratamiento de datos ausentes, formato y aprobación humana. No uses valores de una semana como reglas fijas. Cada cifra de salida debe ser reconciliable con el CSV y cada acción con el registro. Entrégame el texto para `skill_status_urbanfit.md`.

**Prompt de ejecución:** «Ejecuta `skill_status_urbanfit.md` para la semana `2026-W46`. Usa los archivos UrbanFit. Devuelve status y evidencias; compara W45 solo donde la fuente es completa. Señala faltantes y decisiones pendientes.»

## Casos mínimos de prueba
| ID | Solicitud | ¿Activar la skill? | Criterio |
|---|---|---|---|
| T01 | «Genera status semanal W45» | Sí | Cifras y decisiones correctas |
| T02 | «Genera status semanal W46» | Sí | Incluye dato MQL ausente |
| T03 | «Dame tres conceptos de banner» | No | No crea status |
| T04 | «Resume este email» | No | No crea status |
| T05 | Repite T02 tres veces | Sí | KPI invariantes entre intentos |
| T06 | Quita `horas_equipo.csv` y repite T02 | Sí | No inventa horas; declara limitación |

## Criterios objetivos de aceptación
- Todos los KPI calculables de W46 cuadran con sus filas de origen; no mezcla honorarios y medios.
- Identifica **al menos una ausencia de datos** y una desviación de objetivo real.
- Incluye horas planificadas vs reales y próximos compromisos con dueños identificados.
- 2/2 pruebas positivas y 2/2 negativas correctas; T05 sin variación de cifras; T06 sin horas inventadas.
- El procedimiento está versionado y la aprobación humana es explícita.

## Reflexión de rol
¿Cómo convertirías esta skill en una capacidad reutilizable de la agencia, sin que su comportamiento cambie por las particularidades de un cliente?

# Práctica 02 · Auditoría iterativa de un plan de lanzamiento
**Área:** Project + Product | **Duración:** 75–100 min | **M07 · L3 y M09 · L4**

## Caso realista
Pablo (PM) debe decidir si el plan de rediseño de CasaVerde está listo para presentarlo a la directora ecommerce. Existe una planificación propuesta y una nota generada por IA, pero no están validadas.

## Archivos de entrada
1. `01_DATOS/CASAVERDE/brief_proyecto.md`
2. `01_DATOS/CASAVERDE/plan_propuesto_no_validado.csv`
3. `01_DATOS/CASAVERDE/presupuesto_autorizado.csv`
4. `01_DATOS/CASAVERDE/backlog_producto.csv`
5. `01_DATOS/CASAVERDE/nota_estado_no_validada.md`
6. `01_DATOS/CASAVERDE/reunion_2026-11-05.md`
7. `01_DATOS/CASAVERDE/reunion_2026-11-12.md`

## Entregables
- `auditoria_plan.csv`: ID, problema verificable, archivo/ID de evidencia, impacto, severidad (1–3), corrección propuesta, requiere aprobación.
- `plan_corregido_propuesto.csv`: conserva los IDs de actividades y distingue **fecha tentativa** de baseline aprobado.
- `decision_go_live.md`: recomendación de máximo 1 página al comité, incertidumbres y próximo paso autorizado.
- `bitacora_iteraciones.md`: cambios tras las revisiones y criterios de parada.

## Pasos
1. Extrae una **matriz de requisitos no negociables**: presupuesto, fecha contractual, alcance MVP, gates, aprobador.
2. Identifica contradicciones entre presupuesto, plan, backlog, reuniones y nota. **No confíes en la nota no validada.**
3. Pide al modelo un plan corregido **como propuesta**, sin publicar cambios ni afirmar autorizaciones no documentadas.
4. Evalúa el plan: suma de partidas; relación predecesor/sucesor; fechas en relación con dependencias; QA/UAT/consentimiento; adecuación al MVP.
5. Realiza **máximo dos iteraciones de crítica y corrección**. En cada vuelta, exige que el crítico cite un ID o fragmento. Si no hay nuevos fallos comprobables, detén el ciclo.
6. Plantea una decisión humana: qué puede prepararse ya, qué requiere aprobación y qué se debe escalar a Miriam.
7. Registra las condiciones de parada y qué no ha podido verificarse.

## Prompt inicial
> Eres PM senior que audita un plan de rediseño ecommerce. Antes de proponer cambios, construye un inventario de restricciones confirmadas desde el brief y las reuniones. Revisa después el calendario, presupuesto, dependencias, alcance MVP y gates de QA/UAT. Por cada incidencia, referencia archivo, ID y fecha, y prioriza por riesgo. Corrige únicamente como PROPUESTA NO APROBADA. Revisa adversarialmente el resultado hasta dos rondas; no fuerces críticas inventadas. Si falta una decisión del cliente, marca PENDIENTE. Nunca cambies el baseline por iniciativa propia.

## Verificación y aprobación
- El presupuesto calculado coincide con las seis partidas autorizadas.
- Ninguna tarea empieza antes de terminar su dependencia obligatoria, salvo que se explicite un solapamiento autorizado y comprobable.
- El lanzamiento se sitúa después de QA y UAT satisfactorios; no equivale a publicar.
- Las peticiones B2B y de nueva fecha se tratan como propuestas hasta aprobarlas.
- El documento recomienda **una decisión concreta**: replanificar, validar con cliente y mantener gates.

## Reflexión
¿Por qué un plan visualmente impecable puede ser una mala decisión de proyecto? ¿Qué pruebas impiden la complacencia del evaluador IA?

# Práctica 04 · Actas, decisiones y control de cambios
**Área:** Project Management + gobierno de producto | **Duración:** 55–75 min | **M04 · L1**

## Caso realista
Después de dos reuniones de CasaVerde, aparecen cambios de fecha sugeridos, peticiones adicionales y responsabilidades aún sin asignar. Pablo necesita un acta profesional y un registro auditable de decisiones.

## Entradas
1. `01_DATOS/CASAVERDE/brief_proyecto.md`.
2. `01_DATOS/CASAVERDE/reunion_2026-11-05.md`.
3. `01_DATOS/CASAVERDE/reunion_2026-11-12.md`.
4. `01_DATOS/CASAVERDE/backlog_producto.csv`.

## Entregables
- `acta_2026-11-12.md`: asunto, asistentes conocidos, contexto, acuerdos y puntos abiertos. No inventar asistentes ni acta aprobada.
- `registro_decisiones.csv`: ID, fecha, decisión/propuesta, estado, aprobador, evidencia literal.
- `acciones_y_bloqueos.csv`: ID, acción, responsable o `NO ASIGNADO`, vencimiento o `POR DEFINIR`, bloqueo, fuente.
- `control_cambios.md`: diferencias 05→12, impacto probable y circuito de aprobación.
- `correo_borrador_para_aprobacion.md`: borrador, **no enviado**, que solicita la aprobación/confirmación necesaria.

## Pasos
1. Extrae solo acuerdos con soporte literal. Distingue **fecha objetivo, nueva fecha propuesta y nueva fecha aprobada**.
2. Identifica solicitudes de nuevas funcionalidades y qué autoridad tienen quienes las proponen.
3. Compara las dos reuniones: qué se mantiene, qué cambia, qué ha quedado bloqueado.
4. Para tareas, conserva quién y cuándo solo si están documentados; los vacíos son pendientes reales.
5. Propón un correo a Miriam con decisiones específicas que debe confirmar. No añadas compromisos distintos de los registrados.
6. Realiza una segunda lectura de los fragmentos citados antes de dar el acta por lista para revisión humana.

## Prompt listo para copiar
> Con estas dos transcripciones y el brief, actúa como PM documental. Produce acta de la última reunión, registro de decisiones, acciones, bloqueos y delta frente a la anterior. Para cada acuerdo usa una cita breve de transcripción con minuto, autor y fecha. Etiqueta APROBADO, PROPUESTO o NO CONFIRMADO; no confundas una solicitud con un cambio autorizado. Si faltan responsable o fecha, indícalo explícitamente. Finalmente redacta un email de solicitud de confirmación, sin enviarlo.

## Aceptación
- Mantiene separado go-live contractual de propuesta de aplazamiento.
- No incluye portal B2B como MVP aprobado.
- Muestra un bloqueo relacionado con UI y checkout; detecta una responsabilidad no asignada.
- Cada acción importante tiene evidencia; no inventa fechas ni decisiones.
- El correo propone exactamente lo que debe decidir Miriam.

## Reflexión
¿Qué información debe registrarse en una reunión de cliente para que una IA pueda mantener el plan sin alterar acuerdos contractuales?

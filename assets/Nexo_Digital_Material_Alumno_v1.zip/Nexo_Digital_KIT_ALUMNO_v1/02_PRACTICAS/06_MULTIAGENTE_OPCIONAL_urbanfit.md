# Práctica 06 · Coordinación multiagente: ¿aporta valor?
**Área:** Transformación + PM + Marketing/Product | **Nivel:** avanzado opcional | **Duración:** 90–120 min | **M08 · L1/L3**

## Caso realista
UrbanFit prepara una campaña multicanal de enero de 2027. Hay estrategia, creatividad, UX, reporting, dependencias y aprobaciones de cliente. La dirección de Nexo quiere saber si conviene usar agentes especializados coordinados o un solo agente bien contextualizado.

## Entradas
- `01_DATOS/URBANFIT/brief_lanzamiento_2027.md`
- `01_DATOS/URBANFIT/calendario_social_enero.csv`
- `00_AGENCIA/contexto_agencia.md`
- `00_AGENCIA/reglas_de_trabajo.md`

## Experimento A — Un agente
1. En un único chat, entrega brief y calendario; solicita un plan operativo completo.
2. Pide estrategia de públicos/mensajes, entregables creativos, cronograma, dependencias, riesgos, gates y métrica de seguimiento.
3. Conserva salida, nº de correcciones y tiempo de trabajo observables. No inventes consumo de tokens si no se muestra.

## Experimento B — Equipo coordinado
1. Crea tres hilos independientes: **Estrategia**, **Contenido/Producto**, **PM/QA**. Pueden ser chats separados, no requiere software multiagente.
2. **Coordinador** asigna un brief común y objetivos medibles; entrega a cada agente solo lo necesario.
3. **Estrategia**: audiencia, mensajes, hipótesis, riesgos y condiciones de éxito. Debe entregar `estrategia.md`.
4. **Contenido/Producto**: secuencia social, 6 banners, 4 copies, dos variantes de landing, especificaciones y dependencias; entrega `plan_creativo.md`.
5. **PM/QA**: cronograma con responsables y aprobaciones, riesgos, controles, medición y restricciones; entrega `plan_ejecucion.md`.
6. Coordinador revisa contradicciones entre los tres y solicita **una única ronda** de corrección. No se asume sincronización automática entre chats.
7. Antes de declarar «listo para lanzar», exige aprobación de cliente y QA de tracking/landings. Nadie activa campañas.

## Prompts listos para copiar
**Coordinador:**
> Eres el coordinador de campaña UrbanFit 2027. Divide el trabajo en estrategia, contenido/producto y PM/QA. Mantén una matriz de dependencias y una única versión de fechas, presupuesto y objetivos. Solo integrarás resultados si cumplen las restricciones del brief. Registra discrepancias sin inventar acuerdos. No ejecutes ninguna acción externa.

**Agente de estrategia:**
> Entrega hipótesis y propuesta de segmentos, mensajes y funnel para el brief. Diferencia objetivos, hipótesis y hechos documentados. No prometas conversiones inexistentes.

**Agente de contenido/producto:**
> Convierte objetivos y decisiones de estrategia en entregables creativos y UX verificables, respetando el calendario social, aprobaciones y capacidad del equipo. No uses claims sanitarios inventados.

**Agente PM/QA:**
> Diseña plan con dependencias, capacidades disponibles, hitos, aprobación del cliente, pruebas de landing/tracking, riesgos y estado de cada gate. Ninguna fecha propuesta sustituye un compromiso aprobado.

## Entregables
- `experimento_A_un_agente.md` y `experimento_B_equipo.md`.
- `matriz_dependencias.csv` y `log_conflictos.md`.
- `comparativa_A_B.md`: tabla de tiempo observado, nº de correcciones, errores justificados, trazabilidad, esfuerzo de coordinación y coste disponible (o `NO CONSTA`).
- Conclusión: ¿un agente o tres? **Se permite concluir que un único agente es mejor.**

## Criterios de aceptación
- Todos los hitos de diciembre y enero conservan dependencias; no publica antes de gates.
- Ningún agente modifica presupuesto de 30.000 € ni inventa resultados futuros.
- El coordinador detecta contradicciones y las resuelve por referencia a brief, no por mayoría de agentes.
- Comparación A/B aplica la **misma rúbrica**, no compara estilos o longitud solamente.
- La recomendación presenta el coste de coordinación, no da por buena la complejidad por sí misma.

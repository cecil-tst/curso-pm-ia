# Nexo Digital · Contexto empresarial

**Organización ficticia** fundada en Barcelona; 35 empleados; operación B2B y B2C para clientes españoles. Fecha de corte de toda la simulación: **16/11/2026**, salvo que el documento indique otra fecha.

## Modelo de negocio y servicios
- **Consultoría y estrategia digital:** auditorías, posicionamiento, funnels, contenidos, adquisición, CRO.
- **Publicidad y producción creativa:** paid media, banners, landing pages, piezas de vídeo y anuncios display.
- **Social media y contenido:** calendario editorial, redacción, diseño, producción y medición.
- **Productos digitales:** webs, ecommerce, intranets, herramientas internas y portales.
- **Datos y negocio:** dashboards, instrumentación, CRM, automatizaciones y reporting de ventas.

## Equipo (35 personas)
| Área | Personas | Responsabilidad |
|---|---:|---|
| Dirección | 2 | Dirección comercial y operaciones |
| Cuentas y project management | 6 | Cliente, alcance, calendario y seguimiento |
| Estrategia e investigación | 4 | Diagnóstico, discovery, objetivos y medición |
| Performance marketing | 5 | Google Ads, Meta Ads y optimización |
| Creatividad y diseño | 7 | Banners, diseño gráfico, campañas y UX visual |
| Contenidos y redes | 5 | Editorial, copy, comunidad y producción |
| Producto y UX | 3 | Requisitos, backlog, entrevistas y pruebas |
| Ingeniería y datos | 3 | Desarrollo web, CRM, integraciones y analítica |
| **Total** | **35** | |

## Clientes activos para este laboratorio
| Cliente | Sector | Servicios | Responsable Nexo |
|---|---|---|---|
| **UrbanFit** | Cadena de gimnasios | Estrategia de captación, Google/Meta Ads, creatividades y reporting semanal | Laura Rius · Account/PM |
| **CasaVerde** | Ecommerce de decoración | Discovery, CRO, UX y rediseño ecommerce | Pablo Serra · PM; Clara Puig · Product |
| **MedNova** | Operador de servicios B2B para clínicas | Intranet comercial, CRM de oportunidades y automatizaciones | Sara Vidal · Product; David Costa · IT |
| **DistribuMax** | Distribución mayorista B2B | Dashboard de ventas, conexión con CRM, seguimiento comercial | Marina Soler · Datos/PM |

## Tres perspectivas en el mismo escenario
- **Project Management:** presupuesto, alcance, equipo, riesgos, cambios, plan y ejecución.
- **Product Management:** problema, usuarios, descubrimiento, hipótesis, backlog, pruebas y resultados.
- **Transformación empresarial:** estandarizar flujos, definir propietarios, medir adopción y asegurar uso seguro de la IA.

## Normas de trabajo
1. Cada documento tiene propietario y fecha. Si dos fuentes chocan, escalar; no elegir arbitrariamente.
2. Los datos de plataformas y ERP/CRM son simulados. Los informes son una interpretación, no una fuente primaria.
3. Presupuesto de servicios de agencia, inversión publicitaria y presupuesto de proyecto son conceptos distintos.
4. Una intervención de IA nunca aprueba gasto, cambios de alcance, lanzamiento o comunicaciones con terceros.
5. Los materiales de MedNova se limitan a clientes corporativos y oportunidades comerciales: **no se incluyen datos de pacientes**.

# Jerarquía y procedencia de fuentes

1. **Brief confirmado / acuerdos firmes:** fuente de alcance y límites, salvo cambio autorizado.
2. **Datos operativos exportados:** fuente primaria para cifras (si tienen identificadores únicos, filtros documentados y corte definido).
3. **Transcripción literal:** fuente de lo expresado; no equivale automáticamente a acta aprobada.
4. **Notas de estado / borradores:** pueden estar desactualizados o contener errores. Sirven para contrastar, no para decidir.
5. **Salida de IA:** hipótesis, transformación o propuesta; requiere comprobación.

No se suministran credenciales, contactos reales ni datos comerciales de clientes existentes. Los CSV y archivos XLSX contienen la misma información de base.

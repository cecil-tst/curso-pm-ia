# Manual de trabajo · Nexo Digital

## Definiciones de estado
- **Confirmado:** decisión explícitamente aprobada por quien tiene autoridad.
- **Propuesto:** opción pendiente de respuesta; no debe modificarse el baseline.
- **Pendiente / no consta:** falta información; requiere pregunta o validación.
- **Detectado por IA:** hallazgo por comprobar, nunca una verdad automática.

## Revisión previa a entrega
1. ¿Los importes y fechas se pueden reconciliar con los archivos de entrada?
2. ¿Se distinguen las afirmaciones verificables de las hipótesis o recomendaciones?
3. ¿El entregable incluye fuentes precisas (archivo, ID, fecha)?
4. ¿Se registran límites, datos faltantes, riesgos y decisiones pendientes?
5. ¿No se han inventado responsables, aprobaciones ni valores ausentes?
6. ¿Se han probado casos negativos, extremos y cambios que podrían romper el resultado?
7. ¿Hay responsable humano para la validación antes de compartir o ejecutar?

## Riesgos de IA a gestionar
- Lectura parcial de ficheros, invención de datos, mezcla de presupuestos y fuentes.
- Confusión entre acuerdo y propuesta, especialmente en transcripciones.
- Cambios de configuración / skills sin ensayo ni control de versiones.
- Datos comerciales sensibles y acceso de agentes a herramientas reales.

**Marco del ejercicio:** todos los nombres de personas y compañías son inventados. Solo trabaja con archivos de simulación.

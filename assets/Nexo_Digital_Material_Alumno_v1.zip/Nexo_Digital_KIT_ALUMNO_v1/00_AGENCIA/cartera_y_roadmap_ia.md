# Nexo Digital · Transformación interna y cartera de proyectos

## Problema operativo
La agencia dedica demasiadas horas a consolidar reportes de campañas, localizar acuerdos de reuniones y reunir datos de distintas plataformas para propuestas. Sus equipos trabajan con herramientas y formatos diferentes.

## Objetivos de los pilotos de IA (simulados)
| Piloto | Dueño | Hipótesis | KPI antes/después | Guardia de control |
|---|---|---|---|---|
| Informes semanales de clientes | Laura Rius | Menos horas de consolidación sin perder calidad | Mediana de horas/informe y tasa de incidencias por reporte | Revisión por PM antes del envío |
| Registro de decisiones de proyectos | Pablo Serra | Reducir acuerdos olvidados | % de acciones con responsable y fecha; discrepancias detectadas | Aprobación del acta por asistentes |
| Discovery y propuestas de producto | Sara Vidal | Disminuir ciclos de aclaración de requisitos | Nº de preguntas abiertas tras kickoff; retrabajo en especificación | Validación por cliente/Product |
| Reporting comercial consolidado | Marina Soler | Aumentar confianza en métricas | % indicadores con fuente, definición y reconciliación | Controller comercial aprueba |

## Línea base de negocio
No se dispone de métricas históricas auditadas de productividad. **El alumno no debe inventar ahorros ni ROI de IA.** Para diseñar un piloto, debe proponer cómo medirlos en 4 semanas, con una semana inicial de base y un registro manual de errores.

## Limitaciones
- Pilotos con datos anonimizados o sintéticos y permisos mínimos.
- Toda modificación de CRM, lanzamiento, inversión publicitaria o comunicación comercial exige aprobación humana.
- El contenido puede mejorarse con IA, pero la política de marca y la estrategia requieren validación de cliente.

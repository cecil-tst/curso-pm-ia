# SKILL · [nombre de procedimiento]
**Versión:** 0.1 | **Propietario:** [rol] | **Última revisión:** [fecha]

## Descripción y activación
- **Se activa cuando:** [peticiones y condiciones observables].
- **No se activa cuando:** [peticiones cercanas pero diferentes].
- **Entradas mínimas:** [fuentes con periodo y procedencia].
- **Si falta una entrada:** [salida de límite, sin inventar].

## Procedimiento
1. [Validar esquema de archivos, fecha, permisos].
2. [Aplicar reglas de cálculo / extracción y preservar trazabilidad].
3. [Señalar anomalías, incertidumbres y decisiones humanas].
4. [Producir artefacto con formato estable].
5. [Revisar antes de entregar; no actuar externamente sin aprobar].

## Restricciones explicadas
- [Regla y motivo empresarial].

## Casos de prueba
| ID | Entrada | Resultado esperado | Resultado observado | Pasó / falló |
|---|---|---|---|---|
| | | | | |

## Historial de mejoras
| Versión | Fallo reproducible | Modificación mínima | Pruebas repetidas | Aprobador |
|---|---|---|---|---|
| | | | | |

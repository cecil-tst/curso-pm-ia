# Matriz de evidencias y control de calidad

| ID | Afirmación/hallazgo | Fuente: archivo y fila/minuto | Hecho/hipótesis | Impacto | Decisión/acción | Verificador humano |
|---|---|---|---|---|---|---|
| | | | | | | |

**Checklist:** identificadores únicos; fórmulas y unidades; fecha de corte; responsabilidad; decisiones autorizadas; datos faltantes; límites; cambios bajo control.

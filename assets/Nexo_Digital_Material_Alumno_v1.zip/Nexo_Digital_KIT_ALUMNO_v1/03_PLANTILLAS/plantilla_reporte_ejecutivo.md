# Estado ejecutivo · [cliente y proyecto]
**Periodo:** [...] | **Fuente de referencia:** [...] | **Aprobación:** PENDIENTE

## En 30 segundos
- **Objetivo:** ...
- **Resultado observado:** ...
- **Desviación importante:** ...
- **Decisión requerida a [rol]:** ...

## KPI y criterios
| Indicador | Valor | Objetivo | Diferencia | Fuente exacta | Completo? |
|---|---:|---:|---:|---|---|

## Riesgos y siguiente semana
| Riesgo/acción | Responsable | Fecha | Evidencia | Estado |
|---|---|---|---|---|

## Datos no disponibles y supuestos
[No ocultar vacíos ni convertirlos en cero]

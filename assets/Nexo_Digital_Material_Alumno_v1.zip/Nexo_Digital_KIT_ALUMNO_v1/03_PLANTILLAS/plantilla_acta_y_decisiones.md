# Acta [cliente / proyecto] · [fecha]
**Borrador para validación. No equivale a aprobación.**

## Contexto y participantes confirmados
[Fuente, sesión, propósito]

## Decisiones aprobadas
| ID | Decisión | Persona con autoridad | Fuente exacta (tiempo/archivo) | Impacto |
|---|---|---|---|---|

## Propuestas y preguntas sin aprobar
| ID | Propuesta | Estado | Quién debe resolverlo | Evidencia |
|---|---|---|---|---|

## Acciones y bloqueos
| ID | Tarea | Responsable o NO ASIGNADO | Fecha o POR DEFINIR | Evidencia |
|---|---|---|---|---|

## Cambios vs reunión anterior
[Qué cambió, cuándo y con qué grado de autorización]

## Validación
[Quién debe revisar el acta y confirmar decisiones]

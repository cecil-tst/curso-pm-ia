# Rúbrica común del laboratorio (100 puntos)

| Dimensión | Puntos | Criterio verificable |
|---|---:|---|
| Fidelidad a las fuentes | 25 | Cifras y acuerdos reproducibles; ninguna invención |
| Decisiones y valor de negocio | 20 | Recomendación concreta que responde al problema |
| Calidad de la ejecución | 20 | Entregables completos, cálculos/estados correctos |
| Identificación de riesgos y vacíos | 15 | Distingue dato ausente, propuesta y aprobación |
| Trazabilidad y auditabilidad | 10 | Archivos, IDs, fechas, versión y responsable |
| Claridad y usabilidad profesional | 10 | Un responsable puede usarlo sin reinterpretar |

**Mínimo de aprobación sugerido:** 80/100 **y ningún error crítico** (gasto inventado, publicación no autorizada, afirmación de dato ausente como hecho, manipulación de datos sin traza). La puntuación no puede compensar errores críticos de seguridad, datos o autorización.

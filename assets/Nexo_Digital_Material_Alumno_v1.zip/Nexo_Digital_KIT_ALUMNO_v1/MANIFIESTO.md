# Manifiesto de archivos y control de integridad

Paquete: Nexo Digital alumno v1. Datos ficticios.

| Archivo | SHA256 |
|---|---|
| `00_AGENCIA/cartera_y_roadmap_ia.md` | `2104fea4ad154cb49acc7129411eb48a07988e1201aacfeb575d2e1af20109ba` |
| `00_AGENCIA/contexto_agencia.md` | `77ed351b69f904a61051c7e3839f0c31c46c77964162457cd0270f044a85650c` |
| `00_AGENCIA/guia_de_fuentes.md` | `110656c973d19cb95f27f6361bb77340e5f58f4f262d00a71c6913a282836968` |
| `00_AGENCIA/reglas_de_trabajo.md` | `2943060a524c4f1f5b067866c30457bfa1d53a3876438a85dd0fb06ff2061319` |
| `01_DATOS/CASAVERDE/backlog_producto.csv` | `a934167d51e527da3479ebf22977b94873d0e14565341165ad73568e683cb821` |
| `01_DATOS/CASAVERDE/brief_proyecto.md` | `5c0d28c9a62535c5740453bc3c533d3026582da9214f763e5509aa0c3a588345` |
| `01_DATOS/CASAVERDE/nota_estado_no_validada.md` | `eec44523210ac2375f46448d5147cef9c662e5c208e61e5b9cb8b217a0499f4d` |
| `01_DATOS/CASAVERDE/plan_propuesto_no_validado.csv` | `d7267ce6408e6baa39a1e7f511d94368821d12e256ec70719918c0dcc312f88a` |
| `01_DATOS/CASAVERDE/presupuesto_autorizado.csv` | `0831f60dec84d9d0cb0f4fc1baf7c315db5c581c4019f0d611f10ee5a2a694ca` |
| `01_DATOS/CASAVERDE/reunion_2026-11-05.md` | `1cfeb1a623a4a81f9aa058d83828930590fd9e5bfca7afffbd03c297db2b9bb3` |
| `01_DATOS/CASAVERDE/reunion_2026-11-12.md` | `b435e85ee7032f2ee66c36e44ebc219345f64dd2d7c038332d3ceb250e235ce9` |
| `01_DATOS/DISTRIBUMAX/diccionario_kpi.md` | `a53d083c56e0438429d94bf9396ee52a2d0c298610a742ab01da45a3922ca6de` |
| `01_DATOS/DISTRIBUMAX/oportunidades_crm.csv` | `1bd17e00eb8a8c7b63cd32e775b9b0a8f9669d078a04d704141ae58f58e39f72` |
| `01_DATOS/DISTRIBUMAX/probabilidades_etapas.csv` | `3bd3951dce7ee13d7c1f9753b74328a90b994d28b2b4d51fa32d8b1c2e5a6f86` |
| `01_DATOS/DISTRIBUMAX/resumen_comercial_borrador.md` | `639e139c53d1513512f00283c6b76a2528b65afc104ce4ab1e5356782dcdd496` |
| `01_DATOS/DISTRIBUMAX/ventas_octubre_2026.csv` | `6eb2d62b49a52f1bdbc237fc71c9a5e346e5321ba71f1c28c0b7a32d0cc18e20` |
| `01_DATOS/LIBRO_DATOS_NEXO.xlsx` | `5eb4991ad689321476f2bbaa58ae1c4b06e862a54f381b842c9b079630f6cd5b` |
| `01_DATOS/MEDNOVA/brief_inicial.md` | `36014af62837fcd2099d4a6d5d2f679045dfe60552f21be842edc72ad8e5fab2` |
| `01_DATOS/MEDNOVA/ficha_respuestas_autorizadas.md` | `40c55c79311ae5e8f8a5db4e62bbf24ff393dc4067c43d210847af19196b9ac7` |
| `01_DATOS/MEDNOVA/notas_de_stakeholders.md` | `50930b4d6b6315c2191912cb0780bad0f1ffee433288b6a472fd248a3dc5b4d8` |
| `01_DATOS/URBANFIT/brief_lanzamiento_2027.md` | `570aff87f8e9de64c8d9f58dd61ee3ee5abbaf7259148c22a85a61990ab864c8` |
| `01_DATOS/URBANFIT/brief_servicio.md` | `fcb509757d0740e9c1dc6a6890272a780feeb7c1321c6c3b0d29557876e5b1ee` |
| `01_DATOS/URBANFIT/calendario_social_enero.csv` | `178de5899a530ab207890fc8745c5c1d121cdb8230302f19ede2fb2c9a5ddb81` |
| `01_DATOS/URBANFIT/horas_equipo.csv` | `26f63b95c003b5e73ab2302d3117bfcbe536956a08b53b75558e02c63fc9984c` |
| `01_DATOS/URBANFIT/pendientes_creativos.md` | `922271b19d3e4366d0f1bfafe59d0820c6a6bf75e1072872ee4803b6a811f58b` |
| `01_DATOS/URBANFIT/rendimiento_ads.csv` | `abf31a0e999e096e650cda866bde33a366ae4a2f0913380e432a671a051dc4da` |
| `02_PRACTICAS/01_skill_reporting_urbanfit.md` | `d0a29d19e58d3019d4ea738a9b1e3a59432190e9ece5e4a24f704d90369d8205` |
| `02_PRACTICAS/02_auditoria_iterativa_casaverde.md` | `c5bce258649f59911592f4879574691df26b0b2193c98045a19df1889b121ee1` |
| `02_PRACTICAS/03_briefing_guiado_mednova.md` | `9e08b6855cd59fdd9ec191318f45ccb074c712c7da7e2e80b4fcb7b8ef5ded91` |
| `02_PRACTICAS/04_reuniones_seguimiento_casaverde.md` | `8e3f1f058c647a82f3e83c42ebca6df5eef3b2a3067569b01fe3c279a075a7e2` |
| `02_PRACTICAS/05_dashboard_distribumax.md` | `1e7f68a191875bfc1c9ab61e4fb134805bc99b778ef61fb81069bd26879a4b04` |
| `02_PRACTICAS/06_MULTIAGENTE_OPCIONAL_urbanfit.md` | `2039895fde75ddaf7c6b86a241a91d1f701de4fdb7abd4e7c70cfc4a3a0aa9bf` |
| `03_PLANTILLAS/plantilla_acta_y_decisiones.md` | `47321c4c7c3864a435df2f1a3a05ca32676409604ac35a821d8bdd820c8032d8` |
| `03_PLANTILLAS/plantilla_matriz_evidencias.md` | `be73d5c6c40ceab010c6018b439b736b44594b38d31cf0c65c923c2d65cd57b5` |
| `03_PLANTILLAS/plantilla_reporte_ejecutivo.md` | `9e4205158ba33fec0f8e172e63797b4f42f0a8e1b4d8979cd5e9d7ddbeddc54b` |
| `03_PLANTILLAS/plantilla_skill.md` | `b91e56d97e0565c806af9dafaef79992371c7e617d8020cca9d96432c333c43d` |
| `03_PLANTILLAS/rubrica_general.md` | `a820e4aaab26d770bb53a97aa83855304e11d3d8feb195a6c93a10847b45ff37` |
| `LEEME_PRIMERO.md` | `44a370364dae7ad94efad507243e3417bb7cf33a1f200aeac246b9174d7aedf5` |

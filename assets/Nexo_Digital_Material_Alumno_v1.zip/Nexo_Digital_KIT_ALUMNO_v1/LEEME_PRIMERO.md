# Nexo Digital · Laboratorio PM / Product / Transformación con IA

**Edición:** 1.0 | **Fecha de corte de la simulación:** lunes 16 de noviembre de 2026 | **Datos:** 100 % ficticios.

## Para qué sirve
Seis prácticas autocontenidas de IA aplicada a proyectos, producto y transformación empresarial en una agencia de marketing digital. No necesitas clientes, cuentas publicitarias, CRM, API ni credenciales reales: los archivos son datos simulados con cifras y contradicciones controladas.

## Ruta recomendada
1. Lee `00_AGENCIA/contexto_agencia.md` y `00_AGENCIA/reglas_de_trabajo.md` (15 min).
2. Elige una práctica en `02_PRACTICAS/`. Empieza por la 03 (briefing) si quieres seguir un ciclo de proyecto, o por la 01 (skills) si ya tienes experiencia con IA.
3. Abre solo los **archivos de entrada indicados** en esa práctica y ejecuta los pasos. Evita alimentar a la IA con todo el paquete de golpe.
4. Crea los entregables solicitados y aplica su rúbrica. Puedes usar ChatGPT, Claude o Gemini; algunas funciones cambian entre productos. Si tu herramienta no permite skills, usa el procedimiento como instrucciones persistentes en un archivo `SKILL.md` y ejecútalo explícitamente.
5. La práctica 06 es avanzada y opcional. Si tu producto no tiene agentes paralelos, puede realizarse con chats independientes, sin conexión automática.

## Estructura
- `00_AGENCIA/`: contexto, organización, clientes, controles y transformación interna.
- `01_DATOS/`: materiales por cliente, con documentos Markdown y tablas CSV.
- `01_DATOS/LIBRO_DATOS_NEXO.xlsx`: tablas de trabajo en formato Excel para trabajar sin importar CSV.
- `02_PRACTICAS/`: seis guías paso a paso, prompts y rúbricas.
- `03_PLANTILLAS/`: plantillas de salida y checklist de aceptación.

## Reglas importantes
- **No presumas que un dato ausente es cero.** Marca `NO CONSTA` o `PENDIENTE DE VALIDAR`.
- **No uses cifras del caso como datos del mundo real.** Clientes, importes, personas, fechas y resultados son ficticios.
- **Una propuesta no es una aprobación.** Mantén trazabilidad de quién dijo qué y cuándo.
- **Nunca ejecutes cambios externos reales.** Los ejercicios usan entorno simulado; no se envían correos, anuncios, facturas ni actualizaciones de CRM.
- **No uses el solucionario como entrada.** Está distribuido por separado para quien imparta el curso.

## Mapa de prácticas y fuentes
| Práctica | Cliente | Archivo inicial | Resultado |
|---|---|---|---|
| 01. Skill de reporting | UrbanFit | `01_DATOS/URBANFIT/brief_servicio.md` | Skill, dos informes y plan de pruebas |
| 02. Auditoría iterativa | CasaVerde | `01_DATOS/CASAVERDE/brief_proyecto.md` | Auditoría y plan corregido |
| 03. Briefing guiado | MedNova | `01_DATOS/MEDNOVA/brief_inicial.md` | Brief, requisitos y dudas |
| 04. Reuniones y cambios | CasaVerde | `01_DATOS/CASAVERDE/reunion_2026-11-05.md` | Acta, decisiones, cambios |
| 05. Dashboard comercial | DistribuMax | `01_DATOS/DISTRIBUMAX/diccionario_kpi.md` | Dashboard y resumen ejecutivo |
| 06. Multiagente (opcional) | UrbanFit / Nexo | `01_DATOS/URBANFIT/brief_lanzamiento_2027.md` | Plan integrado y comparativa |

**Alcance:** este paquete prepara materiales y guías; no modifica el curso online.

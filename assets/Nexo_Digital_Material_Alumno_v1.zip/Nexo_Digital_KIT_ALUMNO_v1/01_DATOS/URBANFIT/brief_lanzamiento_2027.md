# UrbanFit · Campaña multicanal «Vuelve a moverte»
**Tipo:** nuevo proyecto de captación enero de 2027 | **Estado:** briefing confirmado para planificación, ejecución pendiente de aprobación.

## Objetivo de negocio
Generar **400 solicitudes de prueba** durante el periodo **4–31 enero de 2027** sin exceder **30.000 € de medios**. Objetivo de CPL: **≤ 75 €**. Los indicadores son metas, no resultados.

## Entregables solicitados
- **Estrategia:** propuesta de público, mensajes y funnel, con hipótesis y riesgos.
- **Creatividad/contenido:** 6 banners (3 tamaños x 2 mensajes), 8 publicaciones orgánicas, 4 copies para ads y 2 variantes de landing; sin promesas de salud no autorizadas.
- **PM/operaciones:** calendario, dependencias, responsables, gates de aprobación, presupuesto y registro de riesgos.
- **Reporting:** diseño de métricas, periodicidad y decisiones a partir de resultados.

## Restricciones de fecha
- Brief de mensajes aprobado internamente: **09/12/2026**.
- Creatividades y copies listos para revisión del cliente: **15/12/2026**.
- Aprobación del cliente requerida antes de programar: **18/12/2026**.
- QA de landings y tracking con consentimiento: **22/12/2026**.
- Lanzamiento previsto: **04/01/2027**, sujeto a gates anteriores.

## Equipo y capacidad ficticia
| Rol | Capacidad disponible en diciembre | Condición |
|---|---:|---|
| Estrategia | 18 h | Primera validación de mensajes |
| Diseño | 28 h | Produce banners tras estrategia |
| Contenido | 22 h | Copy sujeto a visto bueno |
| Producto/UX | 16 h | Dos variantes de landing |
| Desarrollo | 12 h | Integra landing y analytics |
| PM | 10 h | Coordina aprobación y riesgos |

## Instrucciones de control
El alumno no debe inventar CPA, altas ni ROI: no hay resultados de enero todavía. Nadie puede activar campañas sin la aprobación del cliente. La coordinación debe poder resolverse también por una sola persona con un único agente.

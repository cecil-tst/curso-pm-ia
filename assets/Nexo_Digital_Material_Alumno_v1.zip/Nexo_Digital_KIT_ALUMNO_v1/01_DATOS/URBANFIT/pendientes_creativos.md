# UrbanFit · Registro de acciones comerciales y creativas
**Corte:** 16/11/2026 | **Responsable del registro:** Laura Rius

| ID | Actividad | Dueño | Fecha compromiso | Estado | Bloqueo / decisión |
|---|---|---|---|---|---|
| UF-A01 | Renovar creatividades de Stories | Ana (Diseño) | 18/11/2026 | En curso | Requiere claims finales del cliente |
| UF-A02 | Revisar segmentación de prospección | Bruno (Paid Media) | 17/11/2026 | En curso | Sin bloqueo |
| UF-A03 | Publicar variantes de landing | Clara (Producto) | 20/11/2026 | Pendiente | Requiere aprobación del cliente; no publicar sin ella |
| UF-A04 | Reconciliar MQL faltantes de Stories W46 | Marina (Datos) | 18/11/2026 | Pendiente | Exportación incompleta |
| UF-A05 | Enviar status W46 al cliente | Laura (PM) | 17/11/2026 | Pendiente | Revisión humana obligatoria |

**Nota:** estos son compromisos de trabajo simulados, no aprobaciones de clientes reales.

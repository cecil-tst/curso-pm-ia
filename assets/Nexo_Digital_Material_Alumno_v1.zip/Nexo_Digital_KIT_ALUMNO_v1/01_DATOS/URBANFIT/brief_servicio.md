# UrbanFit · Acuerdo operativo de captación digital
**Propietaria:** Laura Rius (Account/PM) | **Revisión:** 16/11/2026

La cadena UrbanFit contrata a Nexo Digital para gestionar captación mediante Google Ads, Meta Ads, anuncios y diseño de creatividades para sus gimnasios. El servicio de agencia es **7.000 € mensuales**. La inversión en medios se factura y analiza **por separado**.

## Condiciones confirmadas
- Inversión publicitaria prevista para la semana 2026-W46: **7.500 €** (techo operativo, no objetivo de gasto obligatorio).
- Objetivo semanal de altas confirmadas: **75**.
- CPL objetivo: **≤ 19,50 €/lead**.
- Coste por alta confirmado objetivo: **≤ 105 €/alta**.
- Horas de equipo previstas para 2026-W46: **105 h** según `horas_equipo.csv`.
- Una alta confirmada no equivale automáticamente a un lead cualificado; son métricas distintas.
- El dato de leads cualificados de **Meta Stories en 2026-W46 está ausente** en la exportación. No significa cero.

## Definiciones operativas
- **Lead:** solicitud de contacto registrada por las campañas.
- **MQL / lead cualificado:** lead que supera la cualificacion de marketing; el dato puede estar ausente.
- **Alta confirmada:** inscripcion comercial validada; es distinta de lead y MQL.
- **CPL:** inversion publicitaria / leads.
- **Coste por alta:** inversion publicitaria / altas confirmadas.

## Fuentes autorizadas
- `rendimiento_ads.csv`: medición agregada de campañas de pago por semana.
- `horas_equipo.csv`: carga de trabajo por rol; suma simple por semana.
- `pendientes_creativos.md`: acciones abiertas y sus estados.

## Entregable de cuenta
Un status semanal de una página con: inversión, leads, CPL, altas, coste por alta, horas plan vs real, alertas, decisiones necesarias y fuente de cada métrica. Distinguir medios vs honorarios. Prohibido inventar el MQL faltante.

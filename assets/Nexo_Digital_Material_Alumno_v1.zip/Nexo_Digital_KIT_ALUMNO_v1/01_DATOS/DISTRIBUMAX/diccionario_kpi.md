# DistribuMax · Diccionario de datos y KPI
**Fecha de corte:** 16/11/2026 | **Periodo de facturación:** octubre 2026

## Fuentes
- `ventas_octubre_2026.csv`: exportación contable **simulada**, una fila por documento (factura o abono); hay al menos un defecto de exportación que se debe identificar. Importes netos sin IVA.
- `oportunidades_crm.csv`: oportunidades CRM **simuladas** abiertas y cerradas, con importe por oportunidad. No confundir con facturas.
- `probabilidades_etapas.csv`: correspondencias de probabilidad por etapa, **criterio interno ficticio**.

## Indicadores y reglas
1. **Facturación neta octubre (sin IVA):** sumar una única vez los documentos con estado `cobrada` o `pendiente`, más los `abono` negativos; excluir `anulada`. Cada `id_documento` debe ser único; si aparece duplicado, **detener el cálculo bruto**, registrar el duplicado y deduplicar con evidencia.
2. **Importe cobrado neto:** sumar facturas `cobrada` más abonos (suponemos que los abonos ya están contabilizados; esta convención es propia de la simulación). No incluir `pendiente` ni `anulada`.
3. **Importe pendiente:** sumar documentos `pendiente` **sin descontar dos veces abonos**, porque el abono total se aplica a la facturación y al cobro neto por la convención anterior. Es una cifra de *pendiente nominal*.
4. **Pipeline abierto:** sumar importes de etapas `prospecto`, `cualificada`, `propuesta`, `negociacion`; excluir `ganada` y `perdida`.
5. **Pipeline ponderado:** por oportunidad abierta, importe × probabilidad asignada en `probabilidades_etapas.csv`; sumar. No usar 100 % por defecto.
6. **Objetivo de facturación neta octubre:** **145.000 €**. La desviación es facturación neta real menos objetivo, en euros y en porcentaje.

No hay historial de cobros por fecha ni tasas de conversión de leads en estos datos. **No calcular DSO, conversión real o previsión de ingresos garantizados.**

## Entregables del dashboard
Tarjetas KPI de facturación neta, objetivo, diferencia, importe cobrado, pendiente, pipeline abierto y ponderado; gráfico por región; tabla de oportunidades por etapa; lista visible de controles de calidad y exclusiones.

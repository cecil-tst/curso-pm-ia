# CasaVerde · Nota de estado generada por IA · NO VALIDADA
**Corte:** 16/11/2026 | **No usar como fuente primaria**

1. El presupuesto aprobado asciende a **46.000 €**.
2. El cliente ha aprobado el nuevo portal B2B para el MVP.
3. La aprobación de UI ya está cerrada, por lo que se puede desarrollar el checkout sin restricciones.
4. Publicación confirmada para el **4 de diciembre de 2026**.
5. No hay riesgos bloqueantes ni decisiones pendientes.
6. No se necesita prueba específica de checkout ni consentimiento antes de producción.

**Aviso:** el documento es un artefacto de laboratorio con afirmaciones deliberadamente incorrectas. La misión es contrastarlo, no darlo por cierto.

# CasaVerde · Rediseño ecommerce con mejora de conversión
**Propietarios:** Pablo Serra (PM), Clara Puig (Product) | **Fecha de corte:** 16/11/2026

## Contrato y objetivos confirmados
- Presupuesto autorizado de proyecto: **45.000 €**, excluidos anuncios de captación y mantenimiento posterior.
- Arranque: **19/10/2026**. **Go-live contractual previsto: 11/12/2026**, condicionado a QA, UAT y autorización de cliente.
- Alcance del MVP: catálogo, navegación y búsqueda, PDP, carrito, **checkout invitado**, pasarela de pago, etiquetado de analítica con consentimiento y accesibilidad básica.
- El checkout **no puede construirse a partir de diseños sin aprobación**; UX/UI debe cerrar validación antes de integración final.
- Ningún lanzamiento a producción sin validación formal de UAT y autorización de la cliente Miriam.
- Cualquier cambio de alcance debe presupuestarse y aprobarse por escrito.

## Roles de proyecto
- **Miriam**: directora ecommerce y decisora de CasaVerde; aprueba alcance, cambios y fecha de salida.
- **Javier**: responsable comercial de CasaVerde; propone oportunidades, no aprueba cambios.
- **Pablo**: PM de Nexo; mantiene plan, registro de cambios y riesgos.
- **Clara**: Product Manager; requisitos, backlog y aceptación de producto.
- **Luis**: líder de desarrollo; integraciones y QA técnico.
- **Paula**: diseño UX/UI y creatividades.

## Estado de los documentos
`plan_propuesto_no_validado.csv` es una **planificación de trabajo no aprobada** con errores por detectar. `nota_estado_no_validada.md` es un borrador generado con IA y no debe tratarse como evidencia.
Las reuniones `reunion_2026-11-05.md` y `reunion_2026-11-12.md` son las fuentes para diferenciar decisiones, solicitudes y propuestas.

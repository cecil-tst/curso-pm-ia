# MedNova · Respuestas autorizadas del cliente para entrevista simulada
**Fuente:** Eva Martín · 16/11/2026 | **Uso:** consultar solo después de formular la pregunta correspondiente.

Este documento permite simular respuestas del cliente **sin inventar requisitos**. No es un brief aprobado. Cuando una pregunta no pueda resolverse aquí, responder `PENDIENTE DE VALIDAR`.

| Tema preguntado | Respuesta autorizada |
|---|---|
| Problema prioritario | Los comerciales duplican oportunidades y dirección no puede distinguir pipeline abierto de cerrado |
| Usuarios y volumen | 18 usuarios comerciales; 3 responsables regionales; 2 personas de dirección; 23 usuarios nominales en total |
| Indicadores iniciales | Pipeline abierto por etapa, importe ponderado y oportunidades sin próxima acción |
| Herramientas actuales | Excel compartido y correo; no hay decisión sobre CRM comercial futuro |
| Integraciones | Importación CSV en piloto; integración con ERP pendiente de análisis técnico |
| Control de acceso | Comercial ve sus oportunidades; responsable regional ve su región; dirección, visión global |
| Plazo | Deseable disponer de prototipo navegable antes del 18/12/2026; producción NO aprobada para esa fecha |
| Presupuesto | Pendiente de autorización; no existe techo confirmado |
| Datos personales | Solo contactos corporativos y de empleados de ejemplo; prohibido incluir información de pacientes o salud |
| Función extra | Intranet con documentación comercial; edición documental y aprobaciones en segunda fase, por decidir |

**Precaución:** una respuesta de esta ficha aclara contexto, pero no equivale a un requisito firmado. El ejercicio termina con un brief para validar.

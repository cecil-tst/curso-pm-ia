# MedNova · Briefing recibido · INCOMPLETO
**Emisor:** Eva Martín, directora comercial MedNova | **Fecha:** 13/11/2026

«Necesitamos una intranet comercial y un CRM más útil. Ahora mismo tenemos información de oportunidades repartida en Excel, emails y diferentes oficinas. Quiero que dirección vea el pipeline y que el equipo trabaje de forma coordinada. Nos gustaría lanzarlo cuanto antes, si es posible antes de acabar el trimestre. El presupuesto todavía lo tenemos que revisar internamente. Pedidnos una propuesta.»

**Nota de Nexo:** todavía no se ha aprobado alcance, plataforma, presupuesto ni fecha. **No se incluyen datos de pacientes**; el CRM propuesto maneja contactos profesionales, empresas y oportunidades de negocio.

## Tu reto
Actúa como responsable de Discovery / Product. No inventes cifras ni funciones. Solicita un máximo de cinco preguntas **de una en una**, con opciones si ayudan, y construye el primer brief con lo confirmado, hipótesis y asuntos abiertos.

# MedNova · Notas sin consolidar de stakeholders
**Corte:** 16/11/2026

- **Eva (Dirección Comercial):** «Quiero un pipeline único y que no se creen dos oportunidades para la misma operación.»
- **Marcos (IT):** «No sabemos si el ERP actual permite sincronización. En un piloto, solo acepto CSV con datos sintéticos y control de acceso.»
- **Lucía (Operaciones):** «La documentación comercial está dispersa; podemos empezar con lectura y búsqueda de procedimientos.»
- **Tomás (Responsable regional):** «Me preocupan los permisos. Un comercial no debe acceder a cifras de otras regiones.»
- **Eva:** «No pongáis fecha de implantación ni precio cerrado en vuestra primera propuesta.»

**Riesgo conocido:** identificación y deduplicación de oportunidades por organización, contacto y actividad; requiere una política de reconciliación por diseñar.
